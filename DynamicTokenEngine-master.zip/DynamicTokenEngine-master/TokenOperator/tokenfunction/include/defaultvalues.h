#pragma once
namespace defaultvalues {
	static int zero_int = 0;
}